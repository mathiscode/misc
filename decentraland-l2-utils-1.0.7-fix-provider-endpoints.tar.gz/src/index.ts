import * as matic from './matic/index'

export { matic }
